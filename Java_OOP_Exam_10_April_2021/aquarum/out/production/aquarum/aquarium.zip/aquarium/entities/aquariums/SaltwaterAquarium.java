package aquarium.entities.aquariums;

public class SaltwaterAquarium extends BaseAquarium{
    private static final int capacity = 25;
    public SaltwaterAquarium(String name) {
        super(name, capacity);
    }
}
