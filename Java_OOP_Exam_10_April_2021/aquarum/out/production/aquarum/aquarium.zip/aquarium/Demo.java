package aquarium;

import java.util.Scanner;

public class Demo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String str = "StingFish".replace("Fish", "");
        System.out.println(str);
    }
}
